# Tests for `npm install` CLI output.
